<?php
// Simple script to generate a password hash for 'dcr@123'
echo password_hash('dcr@123', PASSWORD_DEFAULT); 