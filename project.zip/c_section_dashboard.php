<?php
require_once 'includes/auth.php';
requireRole('c_section');
require_once 'includes/db.php';

// --- Dashboard Stats ---
$stats = [
    'pending' => 0,
    'verified' => 0,
    'rejected' => 0,
    'pending_payments' => 0,
];
try {
    $stmt = $pdo->query("SELECT cs.status, COUNT(*) as count
        FROM case_status cs
        INNER JOIN (
            SELECT case_id, MAX(created_at) as max_date
            FROM case_status
            GROUP BY case_id
        ) latest ON cs.case_id = latest.case_id AND cs.created_at = latest.max_date
        GROUP BY cs.status");
    while ($row = $stmt->fetch()) {
        if ($row['status'] === 'c_section_review') $stats['pending'] = $row['count'];
        if ($row['status'] === 'c_section_verified') $stats['verified'] = $row['count'];
        if ($row['status'] === 'c_section_rejected') $stats['rejected'] = $row['count'];
    }
    // Pending payments (sum of recommended amounts not yet approved by collector)
    $stmt = $pdo->query("SELECT SUM(recommended_amount) as total FROM compensation_recommendations cr
        LEFT JOIN compensation_approvals ca ON cr.case_id = ca.case_id
        WHERE ca.case_id IS NULL");
    $stats['pending_payments'] = $stmt->fetchColumn() ?: 0;
} catch (PDOException $e) {}

// --- Recent Cases for Verification (last 30 days) ---
$cases = [];
try {
    $stmt = $pdo->prepare("
        SELECT c.*, cs.status as current_status, cs.created_at as status_date
        FROM cases c
        JOIN case_status cs ON c.case_id = cs.case_id
        WHERE cs.created_at = (
            SELECT MAX(created_at) FROM case_status WHERE case_id = c.case_id
        )
        AND cs.status IN ('c_section_review','c_section_verified','c_section_rejected')
        AND cs.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY cs.created_at DESC
    ");
    $stmt->execute();
    $cases = $stmt->fetchAll();
} catch (PDOException $e) {}

// --- Compensation Summary (last 30 days) ---
$compensations = [];
try {
    $stmt = $pdo->prepare("
        SELECT cr.case_id, c.victim_name, cr.recommended_amount, cr.status, cr.created_at
        FROM compensation_recommendations cr
        JOIN cases c ON cr.case_id = c.case_id
        WHERE cr.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ORDER BY cr.created_at DESC
    ");
    $stmt->execute();
    $compensations = $stmt->fetchAll();
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collector Office | C Section Dashboard</title>
    <style>
        :root {
            --primary-blue: #1976d2;
            --dark-blue: #0d47a1;
            --light-blue: #e3f2fd;
            --white: #ffffff;
            --dark: #333333;
            --gray: #e0e0e0;
            --secondary-blue: #0288d1;
            --warning-orange: #ff6d00;
            --danger-red: #d32f2f;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: var(--light-blue); }
        .header { background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue)); color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.2); }
        .header-title { display: flex; align-items: center; gap: 1rem; }
        .badge { width: 50px; height: 50px; background-color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--primary-blue); font-weight: bold; font-size: 1.2rem; border: 2px solid gold; }
        .header-actions button { background-color: var(--danger-red); color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; }
        .container { display: flex; min-height: calc(100vh - 82px); }
        .sidebar { width: 250px; background-color: white; padding: 1.5rem; box-shadow: 2px 0 5px rgba(0,0,0,0.1); }
        .sidebar-menu { list-style: none; margin-top: 2rem; }
        .sidebar-menu li { margin-bottom: 1rem; }
        .sidebar-menu a { display: flex; align-items: center; gap: 0.8rem; color: var(--dark); text-decoration: none; padding: 0.8rem; border-radius: 4px; transition: all 0.3s; }
        .sidebar-menu a:hover, .sidebar-menu a.active { background-color: var(--light-blue); color: var(--primary-blue); }
        .main-content { flex: 1; padding: 2rem; }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 1.5rem; margin-bottom: 2rem; }
        .stat-card { background-color: white; border-radius: 8px; padding: 1.5rem; box-shadow: 0 2px 5px rgba(0,0,0,0.1); display: flex; flex-direction: column; align-items: center; text-align: center; }
        .stat-icon { width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 1rem; font-size: 1.5rem; }
        .stat-icon.pending { background-color: #fff3e0; color: var(--warning-orange); }
        .stat-icon.verified { background-color: var(--light-blue); color: var(--primary-blue); }
        .stat-icon.rejected { background-color: #ffebee; color: var(--danger-red); }
        .stat-icon.payment { background-color: #e3f2fd; color: var(--secondary-blue); }
        .stat-number { font-size: 2rem; font-weight: 700; margin-bottom: 0.5rem; }
        .stat-title { color: var(--dark); font-weight: 600; }
        .dashboard-section { background-color: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 2rem; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section-title { color: var(--primary-blue); margin-bottom: 1.5rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--gray); }
        .case-table { width: 100%; border-collapse: collapse; }
        .case-table th, .case-table td { padding: 1rem; text-align: left; border-bottom: 1px solid var(--gray); }
        .case-table th { background-color: var(--primary-blue); color: white; }
        .case-table tr:nth-child(even) { background-color: var(--light-blue); }
        .case-table tr:hover { background-color: #f5f5f5; }
        .status-badge { display: inline-block; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
        .status-c_section_review, .status-pending { background-color: #fff3e0; color: #e65100; }
        .status-c_section_verified, .status-verified { background-color: var(--light-blue); color: var(--primary-blue); }
        .status-c_section_rejected, .status-rejected { background-color: #ffebee; color: var(--danger-red); }
        .action-link { color: var(--secondary-blue); text-decoration: none; font-weight: 600; }
        .action-link:hover { text-decoration: underline; }
        .quick-actions { display: flex; gap: 1rem; margin-top: 1.5rem; }
        .btn { padding: 0.8rem 1.5rem; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; transition: all 0.3s; }
        .btn-primary { background-color: var(--primary-blue); color: white; }
        .btn-primary:hover { background-color: var(--dark-blue); }
        .btn-secondary { background-color: var(--secondary-blue); color: white; }
        .btn-secondary:hover { background-color: #0277bd; }
        @media (max-width: 768px) { .container { flex-direction: column; } .sidebar { width: 100%; } .stats-grid { grid-template-columns: 1fr 1fr; } .quick-actions { flex-direction: column; } }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-title">
            <div class="badge">C</div>
            <div>
                <h1>Collector Office - C Section</h1>
                <p>SC/ST Atrocity Case Management Dashboard</p>
            </div>
        </div>
        <div class="header-actions">
            <form action="logout.php" method="post" style="display:inline;"><button type="submit"><i class="fas fa-sign-out-alt"></i> Logout</button></form>
        </div>
    </header>
    <div class="container">
        <!-- Sidebar -->
        <div class="sidebar">
            <!-- <div class="user-profile">
                 <h3>Rajesh Verma</h3>
                <p>Designation: Under Secretary (C Section)</p> 
            </div>  -->
            <ul class="sidebar-menu">
                <li><a href="#" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
                <li><a href="#"><i class="fas fa-inbox"></i> New Cases <span class="notification-badge">12</span></a></li>
                <li><a href="#"><i class="fas fa-check-circle"></i> Verified Cases</a></li>
                <li><a href="#"><i class="fas fa-rupee-sign"></i> Compensation</a></li>
            </ul>
        </div>
        <!-- Main Content -->
        <div class="main-content">
            <!-- Dashboard Stats -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon pending"><i class="fas fa-hourglass-half"></i></div>
                    <div class="stat-number"><?php echo $stats['pending']; ?></div>
                    <div class="stat-title">Pending Verification</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon verified"><i class="fas fa-check-circle"></i></div>
                    <div class="stat-number"><?php echo $stats['verified']; ?></div>
                    <div class="stat-title">Verified Cases</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon rejected"><i class="fas fa-times-circle"></i></div>
                    <div class="stat-number"><?php echo $stats['rejected']; ?></div>
                    <div class="stat-title">Rejected Cases</div>
                </div>
                <!-- <div class="stat-card">
                    <div class="stat-icon payment"><i class="fas fa-rupee-sign"></i></div>
                    <div class="stat-number">₹<?php echo number_format($stats['pending_payments']); ?></div>
                    <div class="stat-title">Pending Payments</div>
                </div> -->
            </div>
            <!-- Recent Cases -->
            <div class="dashboard-section">
                <h3 class="section-title">Recent Cases for Verification</h3>
                <table class="case-table">
                    <thead>
                        <tr>
                            <th>Case ID</th>
                            <th>Victim Name</th>
                            <th>Police Station</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cases as $case): ?>
                        <tr>
                            <td>SCST/<?php echo date('Y', strtotime($case['created_at'])); ?>/<?php echo str_pad($case['case_id'], 4, '0', STR_PAD_LEFT); ?></td>
                            <td><?php echo htmlspecialchars($case['victim_name']); ?></td>
                            <td><?php echo htmlspecialchars($case['police_station']); ?></td>
                            <td><span class="status-badge status-<?php echo htmlspecialchars($case['current_status']); ?>"><?php echo ucfirst(str_replace('_', ' ', $case['current_status'])); ?></span></td>
                            <td><a href="review_c_section_case.php?case_id=<?php echo $case['case_id']; ?>" class="action-link">Review</a></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($cases)): ?>
                        <tr><td colspan="5" style="text-align:center; color:#888;">No cases found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <div class="quick-actions">
                    <a href="all_cases.php" class="btn btn-primary"><i class="fas fa-list"></i> View All Cases</a>
                    <a href="search_cases.php" class="btn btn-secondary"><i class="fas fa-search"></i> Advanced Search</a>
                </div>
            </div>
            <!-- Compensation Summary -->
            <div class="dashboard-section">
                <h3 class="section-title">Compensation Summary (Last 30 Days)</h3>
                <table class="case-table">
                    <thead>
                        <tr>
                            <th>Case ID</th>
                            <th>Victim</th>
                            <th>Amount (₹)</th>
                            <th>Status</th>
                            <th>Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($compensations as $comp): ?>
                        <tr>
                            <td>SCST/<?php echo date('Y', strtotime($comp['created_at'])); ?>/<?php echo str_pad($comp['case_id'], 4, '0', STR_PAD_LEFT); ?></td>
                            <td><?php echo htmlspecialchars($comp['victim_name']); ?></td>
                            <td><?php echo number_format($comp['recommended_amount']); ?></td>
                            <td><span class="status-badge status-<?php echo htmlspecialchars($comp['status'] ?? 'pending'); ?>"><?php echo ucfirst($comp['status'] ?? 'Pending'); ?></span></td>
                            <td><?php echo date('d-m-Y', strtotime($comp['created_at'])); ?></td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if (empty($compensations)): ?>
                        <tr><td colspan="5" style="text-align:center; color:#888;">No compensation records found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html> 