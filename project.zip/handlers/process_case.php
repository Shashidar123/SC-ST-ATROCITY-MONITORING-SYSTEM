<?php
require_once '../includes/auth.php';
require_once '../includes/db.php';

// Check if user has required role
$allowed_roles = ['rdo', 'c_section', 'collector', 'social_welfare'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../' . ($_SESSION['role'] === 'rdo' ? 'sp' : $_SESSION['role']) . '_dashboard.php');
    exit;
}

// Get form data
$case_id = $_POST['case_id'] ?? '';
$action = $_POST['action'] ?? ($_GET['action'] ?? '');
$comments = $_POST['comments'] ?? '';

// Validate data
if (!$case_id || !$action) {
    $redirect_page = $_SESSION['role'] === 'c_section' ? 'c_section_dashboard.php' : 'sp_dashboard.php';
    header("Location: ../{$redirect_page}?error=" . urlencode('Invalid request data'));
    exit;
}

// Check if request is AJAX
$is_ajax = (
    (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') ||
    (isset($_SERVER['CONTENT_TYPE']) && strpos($_SERVER['CONTENT_TYPE'], 'application/json') !== false)
);

try {
    // Start transaction
    $pdo->beginTransaction();

    // Get current case status
    $stmt = $pdo->prepare("
        SELECT status 
        FROM case_status 
        WHERE case_id = ? 
        ORDER BY created_at DESC 
        LIMIT 1
    ");
    $stmt->execute([$case_id]);
    $current_status = $stmt->fetchColumn();

    switch ($action) {
        case 'forward_to_collector':
            if ($_SESSION['role'] !== 'c_section') {
                throw new Exception('Unauthorized action');
            }
            // Get breakdown and verification fields
            $breakdown = json_decode($_POST['breakdown'] ?? '[]', true);
            $verification_officer = $_POST['verification_officer'] ?? '';
            $verification_remarks = $_POST['verification_remarks'] ?? '';
            $payment_method = $_POST['payment_method'] ?? '';
            $disbursement_timeline = $_POST['disbursement_timeline'] ?? '';
            if (empty($breakdown) || !$verification_officer || !$verification_remarks || !$payment_method || !$disbursement_timeline) {
                throw new Exception('All verification and compensation fields are required');
            }
            // Calculate total
            $total_amount = 0;
            foreach ($breakdown as $row) {
                $total_amount += floatval($row['amount']);
            }
            // Delete old breakdown rows
            $stmt = $pdo->prepare("DELETE FROM compensation_breakdown WHERE case_id = ?");
            $stmt->execute([$case_id]);
            // Insert new breakdown rows
            $stmt = $pdo->prepare("INSERT INTO compensation_breakdown (case_id, type, amount, remarks) VALUES (?, ?, ?, ?)");
            foreach ($breakdown as $row) {
                $stmt->execute([$case_id, $row['type'], $row['amount'], $row['remarks']]);
            }
            // Insert compensation recommendation
            $stmt = $pdo->prepare("
                INSERT INTO compensation_recommendations (
                    case_id, recommended_amount, recommended_by, verification_officer, verification_remarks, payment_method, disbursement_timeline, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())
            ");
            $stmt->execute([
                $case_id,
                $total_amount,
                $_SESSION['user_id'],
                $verification_officer,
                $verification_remarks,
                $payment_method,
                $disbursement_timeline
            ]);
            // Update case status
            $stmt = $pdo->prepare("
                INSERT INTO case_status (
                    case_id,
                    status,
                    comments,
                    updated_by,
                    created_at
                ) VALUES (?, 'collector_review', ?, ?, NOW())
            ");
            $stmt->execute([
                $case_id,
                $verification_remarks,
                $_SESSION['user_id']
            ]);
            $pdo->commit();
            if ($is_ajax) {
                echo json_encode(['success' => true]);
                exit;
            } else {
                header('Location: ../c_section_dashboard.php?success=1');
                exit;
            }
            break;

        case 'forward_to_c_section':
            if ($_SESSION['role'] !== 'rdo') {
                throw new Exception('Unauthorized action');
            }

            // Insert new status
            $stmt = $pdo->prepare("
                INSERT INTO case_status (
                    case_id,
                    status,
                    comments,
                    updated_by,
                    created_at
                ) VALUES (?, 'c_section_review', ?, ?, NOW())
            ");

            $stmt->execute([
                $case_id,
                $comments,
                $_SESSION['user_id']
            ]);

            $pdo->commit();
            if ($is_ajax) {
                echo json_encode(['success' => true]);
                exit;
            } else {
                header('Location: ../sp_dashboard.php?success=1');
                exit;
            }
            break;

        case 'forward_to_social_welfare':
            if ($_SESSION['role'] !== 'collector') {
                throw new Exception('Unauthorized action');
            }

            $approved_amount = $_POST['approved_amount'] ?? 0;
            $comments = $_POST['comments'] ?? '';

            if (!$approved_amount || !$comments) {
                throw new Exception('Approved amount and comments are required');
            }

            // Insert approved compensation amount
            $stmt = $pdo->prepare("
                INSERT INTO compensation_approvals (
                    case_id,
                    approved_amount,
                    approved_by,
                    created_at
                ) VALUES (?, ?, ?, NOW())
            ");
            $stmt->execute([
                $case_id,
                $approved_amount,
                $_SESSION['user_id']
            ]);

            // Update case status
            $stmt = $pdo->prepare("
                INSERT INTO case_status (
                    case_id,
                    status,
                    comments,
                    created_by,
                    created_at
                ) VALUES (?, 'social_welfare_review', ?, ?, NOW())
            ");
            $stmt->execute([
                $case_id,
                $comments,
                $_SESSION['user_id']
            ]);

            // Log the action for debugging
            error_log("Case {$case_id} forwarded to social welfare. Approval amount: {$approved_amount}");

            $pdo->commit();
            if ($is_ajax) {
                echo json_encode(['success' => true]);
                exit;
            } else {
                header('Location: ../collector_dashboard.php?success=1');
                exit;
            }
            break;

        default:
            throw new Exception('Invalid action');
    }

} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    // Determine the correct dashboard for redirection
    $redirect_page = $_SESSION['role'] === 'c_section' ? 'c_section_dashboard.php' : 'sp_dashboard.php';
    
    // Log error and redirect with error message
    error_log("Error processing case: " . $e->getMessage());
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    } else {
        header("Location: ../{$redirect_page}?error=" . urlencode($e->getMessage()));
        exit;
    }
} 