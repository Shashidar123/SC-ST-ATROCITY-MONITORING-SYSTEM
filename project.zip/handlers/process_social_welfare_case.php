<?php
require_once '../includes/auth.php';
requireRole('social_welfare');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../social_welfare_dashboard.php?error=Invalid request method');
    exit();
}

if (!isset($_POST['case_id']) || !isset($_POST['action']) || !isset($_POST['comments'])) {
    header('Location: ../social_welfare_dashboard.php?error=Missing required fields');
    exit();
}

$case_id = $_POST['case_id'];
$action = $_POST['action'];
$comments = $_POST['comments'];

try {
    // Start transaction
    $pdo->beginTransaction();

    // Verify case exists and is in correct status
    $stmt = $pdo->prepare("
        SELECT c.case_id, cs.status as current_status 
        FROM cases c
        JOIN case_status cs ON c.case_id = cs.case_id
        WHERE c.case_id = ? AND cs.created_at = (
            SELECT MAX(created_at)
            FROM case_status
            WHERE case_id = c.case_id
        )
    ");
    $stmt->execute([$case_id]);
    $case = $stmt->fetch();

    if (!$case) {
        throw new Exception('Case not found');
    }

    if ($case['current_status'] !== 'social_welfare_review') {
        throw new Exception('Case is not in the correct status for this action');
    }

    // Update case status based on action
    $new_status = ($action === 'approve') ? 'compensation_approved' : 'compensation_rejected';
    
    $stmt = $pdo->prepare("
        INSERT INTO case_status (
            case_id,
            status,
            comments,
            created_by,
            created_at
        ) VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([
        $case_id,
        $new_status,
        $comments,
        $_SESSION['user_id']
    ]);

    // Log the action for debugging
    error_log("Social Welfare case {$case_id} {$action}d. New status: {$new_status}");

    // Commit transaction
    $pdo->commit();

    // Redirect with success message
    header('Location: ../social_welfare_dashboard.php?success=1');
    exit();

} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log("Error processing social welfare case: " . $e->getMessage());
    header('Location: ../social_welfare_dashboard.php?error=' . urlencode($e->getMessage()));
    exit();
}
?> 