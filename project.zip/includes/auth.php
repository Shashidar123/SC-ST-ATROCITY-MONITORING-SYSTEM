<?php
session_start();
require_once __DIR__ . '/../includes/db.php';

function authenticate($username, $password) {
    global $pdo;
    
    try {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
        
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            return true;
        }
        return false;
    } catch(PDOException $e) {
        error_log("Authentication error: " . $e->getMessage());
        return false;
    }
}

function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        header('Location: ' . getRoleRedirect($_SESSION['role']));
        exit();
    }
}

function getRoleRedirect($role) {
    switch ($role) {
        case 'admin':
            return 'admin_dashboard.php';
        case 'police':
            return 'police.php';
        case 'c_section':
            return 'c_section_dashboard.php';
        case 'collector':
            return 'collector_dashboard.php';
        case 'social_welfare':
            return 'social_welfare_dashboard.php';
        case 'rdo':
            return 'sp_dashboard.php';
        default:
            return 'login.php';
    }
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function getCurrentUserRole() {
    return $_SESSION['role'] ?? null;
}

function logout() {
    session_destroy();
    header('Location: login.php');
    exit();
}
?> 