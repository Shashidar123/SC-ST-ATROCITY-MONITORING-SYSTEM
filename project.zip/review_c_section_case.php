<?php
require_once 'includes/auth.php';
requireRole('c_section');
require_once 'includes/db.php';

if (!isset($_GET['case_id'])) {
    header('Location: c_section_dashboard.php?error=No case specified');
    exit();
}

$case_id = $_GET['case_id'];

try {
    // Get case details with history
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cs.status as current_status,
            cs.comments as last_comments,
            cs.created_at as status_date,
            u.username as filed_by_name,
            (
                SELECT GROUP_CONCAT(CONCAT(status, ':', comments, ':', created_at) SEPARATOR '||')
                FROM case_status
                WHERE case_id = c.case_id
                ORDER BY created_at ASC
            ) as status_history
        FROM cases c
        JOIN case_status cs ON c.case_id = cs.case_id
        JOIN users u ON c.filed_by = u.id
        WHERE c.case_id = ? AND cs.created_at = (
            SELECT MAX(created_at)
            FROM case_status
            WHERE case_id = c.case_id
        )
    ");
    $stmt->execute([$case_id]);
    $case = $stmt->fetch();

    if (!$case) {
        header('Location: c_section_dashboard.php?error=Case not found');
        exit();
    }

    // Fetch all documents for this case
    $stmt = $pdo->prepare("SELECT * FROM case_documents WHERE case_id = ? ORDER BY created_at DESC");
    $stmt->execute([$case_id]);
    $case_documents = $stmt->fetchAll();

    // Parse status history
    $history = [];
    if ($case['status_history']) {
        foreach (explode('||', $case['status_history']) as $entry) {
            list($status, $comments, $date) = explode(':', $entry);
            $history[] = [
                'status' => $status,
                'comments' => $comments,
                'date' => $date
            ];
        }
    }

} catch(PDOException $e) {
    header('Location: c_section_dashboard.php?error=' . urlencode('Error loading case details'));
    exit();
}

// Fetch compensation breakdown
$breakdown = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM compensation_breakdown WHERE case_id = ?");
    $stmt->execute([$case_id]);
    $breakdown = $stmt->fetchAll();
} catch (PDOException $e) {}
if (empty($breakdown)) {
    $breakdown = [
        ['type' => 'Medical Expenses', 'amount' => '', 'remarks' => ''],
        ['type' => 'Physical Violence', 'amount' => '', 'remarks' => ''],
        ['type' => 'Mental Trauma', 'amount' => '', 'remarks' => ''],
        ['type' => 'Loss of Wages', 'amount' => '', 'remarks' => ''],
    ];
}
// Fetch verification info if present
$verification = [
    'officer' => '', 'remarks' => '', 'payment_method' => '', 'timeline' => ''
];
try {
    $stmt = $pdo->prepare("SELECT verification_officer, verification_remarks, payment_method, disbursement_timeline FROM compensation_recommendations WHERE case_id = ? ORDER BY created_at DESC LIMIT 1");
    $stmt->execute([$case_id]);
    $row = $stmt->fetch();
    if ($row) $verification = $row;
} catch (PDOException $e) {}

// Show confirmation message if redirected after forwarding
if (isset($_GET['forwarded']) && $_GET['forwarded'] === '1') {
    echo '<div id="forward-success" style="background:linear-gradient(90deg,#38a169,#2b6cb0);color:#fff;padding:1.5rem 2rem;border-radius:8px;margin:2rem auto 1rem auto;max-width:700px;box-shadow:0 4px 16px rgba(0,0,0,0.12);font-size:1.3rem;text-align:center;font-weight:600;letter-spacing:0.5px;">
    <i class="fas fa-check-circle" style="font-size:2rem;margin-bottom:0.5rem;"></i><br>
    Case successfully forwarded to Collector!<br>
    <span style="font-size:1rem;font-weight:400;">All details and compensation recommendations have been submitted.<br>Thank you for your prompt action in ensuring justice and support for the victim.</span><br>
    <span id="redirect-msg" style="display:block;margin-top:1rem;font-size:1rem;font-weight:400;">Redirecting to Collector Dashboard in <span id="countdown">3</span> seconds...</span>
    </div>';
    echo '<script>
    let sec = 3;
    let countdown = setInterval(function() {
        sec--;
        document.getElementById("countdown").textContent = sec;
        if (sec <= 0) {
            clearInterval(countdown);
            window.location.href = "collector_dashboard.php";
        }
    }, 1000);
    </script>';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Collector Office | C Section - SC/ST Atrocity Cases</title>
    <style>
        :root {
            --collector-blue: #0a4a7a;
            --collector-dark-blue: #08315a;
            --collector-light: #e9f2f9;
            --collector-white: #ffffff;
            --collector-dark: #333333;
            --collector-gray: #e0e0e0;
            --highlight-blue: #1a73e8;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { background-color: var(--collector-light); }
        .header { background: linear-gradient(135deg, var(--collector-dark-blue), var(--collector-blue)); color: white; padding: 1rem 2rem; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.2); }
        .header-title { display: flex; align-items: center; gap: 1rem; }
        .badge { width: 50px; height: 50px; background-color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: var(--collector-blue); font-weight: bold; font-size: 1.2rem; border: 2px solid gold; }
        .header-actions button { background-color: #d32f2f; color: white; border: none; padding: 0.5rem 1rem; border-radius: 4px; cursor: pointer; }
        .container { display: flex; min-height: calc(100vh - 82px); }
        .main-content { flex: 1; padding: 2rem; }
        .case-header { display: flex; justify-content: space-between; margin-bottom: 2rem; }
        .case-id { background-color: var(--collector-blue); color: white; padding: 0.5rem 1rem; border-radius: 4px; }
        .case-section { background-color: white; border-radius: 8px; padding: 1.5rem; margin-bottom: 2rem; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .section-title { color: var(--collector-blue); margin-bottom: 1.5rem; padding-bottom: 0.5rem; border-bottom: 1px solid var(--collector-gray); }
        .detail-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; }
        .detail-card { background-color: var(--collector-light); padding: 1rem; border-radius: 6px; }
        .detail-row { display: flex; margin-bottom: 0.8rem; }
        .detail-label { font-weight: 600; width: 150px; color: var(--collector-dark); }
        .detail-value { flex: 1; }
        .sp-section { background-color: #e9f2f9; border-left: 4px solid var(--collector-blue); }
        .sp-title { color: var(--collector-blue); }
        .status-badge { display: inline-block; padding: 0.3rem 0.8rem; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
        .status-pending { background-color: #fff3e0; color: #e65100; }
        .status-active { background-color: #e3f2fd; color: #1565c0; }
        .status-completed { background-color: var(--collector-light); color: var(--collector-blue); }
        .action-section { margin-top: 2rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 600; }
        .form-group select, .form-group input, .form-group textarea { width: 100%; padding: 0.8rem; border: 1px solid var(--collector-gray); border-radius: 4px; }
        .form-group textarea { min-height: 120px; resize: vertical; }
        .action-buttons { display: flex; gap: 1rem; margin-top: 1.5rem; }
        .btn { padding: 0.8rem 1.5rem; border: none; border-radius: 4px; font-weight: 600; cursor: pointer; transition: all 0.3s; }
        .btn-primary { background-color: var(--collector-blue); color: white; }
        .btn-primary:hover { background-color: var(--collector-dark-blue); }
        .compensation-table { width: 100%; border-collapse: collapse; margin-top: 1rem; }
        .compensation-table th, .compensation-table td { padding: 0.8rem; text-align: left; border-bottom: 1px solid var(--collector-gray); }
        .compensation-table th { background-color: var(--collector-blue); color: white; }
        .compensation-table tr:nth-child(even) { background-color: var(--collector-light); }
        .amount-input { width: 120px; padding: 0.5rem; border: 1px solid var(--collector-gray); border-radius: 4px; }
        .documents-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 1rem; margin-top: 1rem; }
        .document-card { border: 1px solid var(--collector-gray); border-radius: 4px; padding: 1rem; text-align: center; cursor: pointer; transition: all 0.3s; }
        .document-card:hover { border-color: var(--highlight-blue); box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .document-icon { font-size: 2rem; color: var(--collector-blue); margin-bottom: 0.5rem; }
        @media (max-width: 768px) { .container { flex-direction: column; } .detail-grid { grid-template-columns: 1fr; } .documents-grid { grid-template-columns: 1fr 1fr; } }
    </style>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-title">
            <div class="badge">C</div>
            <div>
                <h1>Collector Office - Anantapur District</h1>
                <p>SC/ST Atrocity Case Management System</p>
            </div>
        </div>
        <div class="header-actions">
            <form action="logout.php" method="post" style="display:inline;"><button type="submit"><i class="fas fa-sign-out-alt"></i> Logout</button></form>
        </div>
    </header>
    <div class="container">
        <div class="main-content">
            <!-- Case Header -->
            <div class="case-header">
                <h2>Case Verification & Compensation</h2>
                <div class="case-id">Case ID: SCST/<?php echo date('Y', strtotime($case['created_at'])); ?>/<?php echo str_pad($case['case_id'], 4, '0', STR_PAD_LEFT); ?></div>
            </div>
            <!-- SP Office Section -->
            <div class="case-section sp-section">
                <h3 class="section-title sp-title">SP Office Submission</h3>
                <div class="detail-grid">
                    <div class="detail-card">
                        <div class="detail-row">
                            <div class="detail-label">Forwarded By:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($case['filed_by_name']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Forwarded Date:</div>
                            <div class="detail-value"><?php echo date('d-m-Y H:i', strtotime($case['status_date'])); ?></div>
                        </div>
                    </div>
                    <div class="detail-card">
                        <div class="detail-row">
                            <div class="detail-label">Case Status:</div>
                            <div class="detail-value">
                                <span class="status-badge status-active"><?php echo ucfirst(str_replace('_', ' ', $case['current_status'])); ?></span>
                            </div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Evidence Status:</div>
                            <div class="detail-value">
                                <span class="status-badge status-completed">Verified</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="detail-card">
                    <div class="detail-row">
                        <div class="detail-label">SP Remarks:</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['last_comments']); ?></div>
                    </div>
                </div>
                <!-- Documents from SP Office -->
                <h4 style="margin-top: 1.5rem; color: var(--collector-blue);">Attached Documents</h4>
                <div class="documents-grid">
                    <?php foreach ($case_documents as $doc): ?>
                    <?php
                        // User-friendly label based on document_type
                        $type_map = [
                            'fir' => 'FIR Copy',
                            'medical' => 'Medical Report',
                            'evidence' => 'Evidence Photo',
                            'statement' => "Victim's Statement",
                            'cctv' => 'CCTV Footage',
                            'charge_sheet' => 'Charge Sheet',
                            'death_certificate' => 'Death Certificate',
                            'postmortem_report' => 'Postmortem Report',
                            'legal_heir_certificate' => 'Legal Heir Certificate',
                            'caste_certificate' => 'Caste Certificate',
                            'appointment_order' => 'Appointment Order',
                            // Add more as needed
                        ];
                        $doc_type_key = strtolower(str_replace(' ', '_', $doc['document_type']));
                        $label = $type_map[$doc_type_key] ?? ucfirst(str_replace('_', ' ', $doc['document_type']));
                        $is_pdf = strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION)) === 'pdf';
                        $icon = $is_pdf ? 'pdf' : (in_array(strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION)), ['jpg','jpeg','png']) ? 'image' : (in_array(strtolower(pathinfo($doc['file_path'], PATHINFO_EXTENSION)), ['mp4','avi']) ? 'video' : 'word'));
                    ?>
                    <a href="uploads/<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" style="text-decoration:none;color:inherit;">
                    <div class="document-card" style="cursor:pointer;">
                        <div class="document-icon">
                            <i class="fas fa-file-<?php echo $icon; ?>"></i>
                        </div>
                        <div style="font-weight:600;margin-bottom:4px;"><?php echo htmlspecialchars($label); ?></div>
                        <div class="detail-value" style="font-size: 0.8rem; color: #666;">Uploaded: <?php echo htmlspecialchars($doc['created_at']); ?></div>
                    </div>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>
            <!-- Case Information -->
            <div class="case-section">
                <h3 class="section-title">Case Summary</h3>
                <div class="detail-grid">
                    <div class="detail-card">
                        <div class="detail-row">
                            <div class="detail-label">FIR Number:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($case['fir_number']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Police Station:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($case['police_station']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Incident Date:</div>
                            <div class="detail-value"><?php echo date('d-m-Y', strtotime($case['incident_date'])); ?></div>
                        </div>
                    </div>
                    <div class="detail-card">
                        <div class="detail-row">
                            <div class="detail-label">Victim Name:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($case['victim_name']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Sections Applied:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($case['case_sections']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Case Severity:</div>
                            <div class="detail-value">High (Physical Violence)</div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Compensation Section -->
            <div class="case-section">
                <h3 class="section-title">Compensation Calculation</h3>
                <form id="compensation-form" method="POST" action="handlers/process_case.php">
                <input type="hidden" name="case_id" value="<?php echo htmlspecialchars($case['case_id']); ?>">
                <input type="hidden" name="action" value="forward_to_collector">
                <table class="compensation-table">
                    <thead>
                        <tr>
                            <th>Compensation Type</th>
                            <th>Proposed Amount (₹)</th>
                            <th>Remarks</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($breakdown as $row): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['type']); ?></td>
                            <td><input type="number" class="amount-input" name="amount[]" value="<?php echo htmlspecialchars($row['amount']); ?>" required></td>
                            <td><input type="text" name="remarks[]" value="<?php echo htmlspecialchars($row['remarks']); ?>" style="width: 100%;"></td>
                        </tr>
                        <?php endforeach; ?>
                        <tr>
                            <td><strong>Total Compensation</strong></td>
                            <td id="total-comp"><strong>0</strong></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
                <!-- C Section Verification -->
                <div class="case-section">
                    <h3 class="section-title">C Section Verification</h3>
                    <div class="form-group">
                        <label>Case Verification Status</label>
                        <select name="verification_status" id="verificationStatus">
                            <option value="pending">Pending Verification</option>
                            <option value="verified" selected>Verified - Eligible for Compensation</option>
                            <option value="rejected">Rejected - Insufficient Evidence</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Verification Officer</label>
                        <input type="text" name="verification_officer" id="verificationOfficer" value="<?php echo htmlspecialchars($verification['officer'] ?? ''); ?>">
                    </div>
                    <div class="form-group">
                        <label>Verification Remarks</label>
                        <textarea name="verification_remarks" id="verificationRemarks" placeholder="Enter verification comments..."><?php echo htmlspecialchars($verification['remarks'] ?? ''); ?></textarea>
                    </div>
                    <div class="form-group">
                        <label>Payment Method</label>
                        <select name="payment_method" id="paymentMethod">
                            <option value="direct" <?php if(($verification['payment_method'] ?? '')==='direct') echo 'selected'; ?>>Direct Bank Transfer</option>
                            <option value="cheque" <?php if(($verification['payment_method'] ?? '')==='cheque') echo 'selected'; ?>>Cheque</option>
                            <option value="dd" <?php if(($verification['payment_method'] ?? '')==='dd') echo 'selected'; ?>>Demand Draft</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Disbursement Timeline</label>
                        <select name="disbursement_timeline" id="disbursementTimeline">
                            <option value="7days" <?php if(($verification['timeline'] ?? '')==='7days') echo 'selected'; ?>>Within 7 days (Priority)</option>
                            <option value="15days" <?php if(($verification['timeline'] ?? '')==='15days') echo 'selected'; ?>>Within 15 days (Normal)</option>
                            <option value="30days" <?php if(($verification['timeline'] ?? '')==='30days') echo 'selected'; ?>>Within 30 days</option>
                        </select>
                    </div>
                    <div class="action-buttons">
                        <button class="btn btn-primary" id="approveBtn" type="submit"><i class="fas fa-check-circle"></i> Approve & Forward to Collector</button>
                    </div>
                </div>
                </form>
            </div>
            <!-- Previous Actions Log -->
            <div class="case-section">
                <h3 class="section-title">Case History</h3>
                <div class="detail-card">
                    <?php foreach ($history as $entry): ?>
                    <div class="detail-row">
                        <div class="detail-label">
                            <?php 
                            $created_at = $entry['created_at'] ?? ($entry['date'] ?? '');
                            if ($created_at) {
                                echo date('d-m-Y H:i', strtotime($created_at));
                            } else {
                                echo '<span style="color:#888;">No date</span>';
                            }
                            ?>
                        </div>
                        <div class="detail-value">
                            <?php echo ucfirst(str_replace('_', ' ', $entry['status'])); ?><?php if (!empty($entry['comments'])) echo ': ' . htmlspecialchars($entry['comments']); ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
    <script>
    // Calculate total compensation dynamically
    function updateTotal() {
        let total = 0;
        document.querySelectorAll('.amount-input').forEach(input => {
            total += parseInt(input.value) || 0;
        });
        document.getElementById('total-comp').innerHTML = '<strong>' + total.toLocaleString('en-IN') + '</strong>';
    }
    document.querySelectorAll('.amount-input').forEach(input => {
        input.addEventListener('input', updateTotal);
    });
    updateTotal();
    </script>
</body>
</html> 