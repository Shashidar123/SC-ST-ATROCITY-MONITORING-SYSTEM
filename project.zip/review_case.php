<?php
require_once 'includes/auth.php';
requireRole('rdo');

if (!isset($_GET['case_id'])) {
    header('Location: sp_dashboard.php?error=No case specified');
    exit();
}

$case_id = $_GET['case_id'];

try {
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cs.status as current_status,
            cs.created_at as status_date,
            u.username as filed_by_name
        FROM cases c
        JOIN case_status cs ON c.case_id = cs.case_id
        JOIN users u ON c.filed_by = u.id
        WHERE c.case_id = ? AND cs.created_at = (
            SELECT MAX(created_at)
            FROM case_status
            WHERE case_id = c.case_id
        )
    ");
    $stmt->execute([$case_id]);
    $case = $stmt->fetch();

    if (!$case) {
        header('Location: sp_dashboard.php?error=Case not found');
        exit();
    }

    // Fetch all documents for this case
    $stmt = $pdo->prepare("SELECT * FROM case_documents WHERE case_id = ? ORDER BY created_at DESC");
    $stmt->execute([$case_id]);
    $case_documents = $stmt->fetchAll();
} catch(PDOException $e) {
    header('Location: sp_dashboard.php?error=' . urlencode('Error loading case details'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Case - SP Office</title>
    <style>
        :root {
            --police-blue: #0a4a7a;
            --police-dark-blue: #08315a;
            --police-light: #e9f2f9;
            --police-white: #ffffff;
            --police-dark: #333333;
            --police-gray: #e0e0e0;
            --collector-green: #2e7d32;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: var(--police-light);
        }

        .header {
            background: linear-gradient(135deg, var(--police-dark-blue), var(--police-blue));
            color: white;
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.2);
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header-actions {
            display: flex;
            gap: 1rem;
        }

        .btn {
            padding: 0.5rem 1rem;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 500;
        }

        .btn-logout {
            background-color: #dc3545;
            color: white;
            border: none;
        }

        .btn-back {
            background-color: var(--police-white);
            color: var(--police-blue);
            border: none;
        }

        .container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .case-section {
            background-color: white;
            border-radius: 8px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .section-title {
            color: var(--police-blue);
            margin-bottom: 1.5rem;
            padding-bottom: 0.5rem;
            border-bottom: 1px solid var(--police-gray);
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 1.5rem;
        }

        .detail-card {
            background-color: var(--police-light);
            padding: 1rem;
            border-radius: 6px;
        }

        .detail-row {
            display: flex;
            margin-bottom: 0.8rem;
        }

        .detail-label {
            font-weight: 600;
            width: 150px;
            color: var(--police-dark);
        }

        .detail-value {
            flex: 1;
        }

        .action-section {
            background-color: white;
            border-radius: 8px;
            padding: 1.5rem;
            margin-top: 2rem;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            font-weight: 500;
        }

        .form-group textarea {
            width: 100%;
            padding: 0.8rem;
            border: 1px solid var(--police-gray);
            border-radius: 4px;
            resize: vertical;
            min-height: 100px;
        }

        .btn-submit {
            background-color: var(--collector-green);
            color: white;
            border: none;
            padding: 0.8rem 2rem;
            font-size: 1rem;
        }

        .status-badge {
            display: inline-block;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.9rem;
            font-weight: 500;
        }

        .status-sp_review {
            background-color: #fff3cd;
            color: #856404;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-title">
            <h1>Review Case #<?php echo htmlspecialchars($case['case_id']); ?></h1>
        </div>
        <div class="header-actions">
            <a href="sp_dashboard.php" class="btn btn-back">Back to Dashboard</a>
            <a href="logout.php" class="btn btn-logout">Logout</a>
        </div>
    </div>

    <div class="container">
        <div class="case-section">
            <h2 class="section-title">Case Details</h2>
            <div class="detail-grid">
                <div class="detail-card">
                    <div class="detail-row">
                        <div class="detail-label">Case Type:</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['case_type']); ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Status:</div>
                        <div class="detail-value">
                            <span class="status-badge status-<?php echo htmlspecialchars($case['current_status']); ?>">
                                <?php echo ucfirst(str_replace('_', ' ', $case['current_status'])); ?>
                            </span>
                        </div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Filed By:</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['filed_by_name']); ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Filed Date:</div>
                        <div class="detail-value"><?php echo date('F j, Y', strtotime($case['created_at'])); ?></div>
                    </div>
                </div>
                <div class="detail-card">
                    <div class="detail-row">
                        <div class="detail-label">Victim Name:</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['victim_name']); ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Victim Address:</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['victim_address']); ?></div>
                    </div>
                    <div class="detail-row">
                        <div class="detail-label">Incident Date:</div>
                        <div class="detail-value"><?php echo date('F j, Y', strtotime($case['incident_date'])); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Case Documents Section -->
        <div class="case-section">
            <h2 class="section-title">Case Documents & Evidence</h2>
            <?php if (!empty($case_documents)): ?>
                <ul style="list-style: none; padding: 0;">
                    <?php foreach ($case_documents as $doc): ?>
                        <li style="margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                            <strong><?php echo htmlspecialchars(ucfirst($doc['document_type'])); ?>:</strong>
                            <a href="uploads/<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" style="margin-left: 10px; color: #3498db; text-decoration: underline;">
                                <?php echo htmlspecialchars($doc['file_path']); ?>
                            </a>
                            <span style="color: #888; margin-left: 10px; font-size: 0.9em;">Uploaded: <?php echo htmlspecialchars($doc['created_at']); ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No documents uploaded for this case.</p>
            <?php endif; ?>
        </div>

        <div class="case-section">
            <h2 class="section-title">Incident Description</h2>
            <p><?php echo nl2br(htmlspecialchars($case['incident_description'])); ?></p>
        </div>

        <form id="forward-form" action="handlers/process_case.php" method="POST" class="action-section">
            <h2 class="section-title">Review Action</h2>
            <input type="hidden" name="case_id" value="<?php echo htmlspecialchars($case['case_id']); ?>">
            <div class="form-group">
                <label for="comments">Comments/Observations:</label>
                <textarea id="comments" name="comments" required></textarea>
            </div>
            <div class="form-group">
                <button type="submit" name="action" value="forward_to_c_section" class="btn btn-submit">
                    Forward to C-Section
                </button>
            </div>
        </form>
    </div>
</body>
</html> 