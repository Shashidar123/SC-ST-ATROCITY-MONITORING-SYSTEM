<?php
require_once 'includes/auth.php';
requireRole('collector');

if (!isset($_GET['case_id'])) {
    header('Location: collector_dashboard.php?error=No case specified');
    exit();
}

$case_id = $_GET['case_id'];

try {
    // Get case details with history and compensation recommendation
    $stmt = $pdo->prepare("
        SELECT 
            c.*,
            cs.status as current_status,
            cs.comments as last_comments,
            cs.created_at as status_date,
            u.username as filed_by_name,
            cr.recommended_amount,
            cr.created_at as recommendation_date,
            (
                SELECT GROUP_CONCAT(CONCAT(status, ':', comments, ':', created_at) SEPARATOR '||')
                FROM case_status
                WHERE case_id = c.case_id
                ORDER BY created_at ASC
            ) as status_history
        FROM cases c
        JOIN case_status cs ON c.case_id = cs.case_id
        JOIN users u ON c.filed_by = u.id
        LEFT JOIN compensation_recommendations cr ON c.case_id = cr.case_id
        WHERE c.case_id = ? AND cs.created_at = (
            SELECT MAX(created_at)
            FROM case_status
            WHERE case_id = c.case_id
        )
    ");
    $stmt->execute([$case_id]);
    $case = $stmt->fetch();

    if (!$case) {
        header('Location: collector_dashboard.php?error=Case not found');
        exit();
    }

    // Fetch all documents for this case
    $stmt = $pdo->prepare("SELECT * FROM case_documents WHERE case_id = ? ORDER BY created_at DESC");
    $stmt->execute([$case_id]);
    $case_documents = $stmt->fetchAll();

    // Parse status history
    $history = [];
    if ($case['status_history']) {
        foreach (explode('||', $case['status_history']) as $entry) {
            list($status, $comments, $date) = explode(':', $entry);
            $history[] = [
                'status' => $status,
                'comments' => $comments,
                'date' => $date
            ];
        }
    }

} catch(PDOException $e) {
    header('Location: collector_dashboard.php?error=' . urlencode('Error loading case details'));
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Case #<?php echo htmlspecialchars($case['case_id']); ?> - Collector</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1e40af;
            --primary-dark: #1e3a8a;
            --secondary-color: #eff6ff;
            --success-color: #059669;
            --warning-color: #d97706;
            --danger-color: #dc2626;
            --background-color: #f3f4f6;
            --text-color: #1f2937;
            --text-light: #6b7280;
            --border-color: #e5e7eb;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.5;
        }

        .header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            color: white;
            padding: 1.5rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .btn {
            padding: 0.625rem 1.25rem;
            border-radius: 0.5rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            border: none;
        }

        .btn-white {
            background-color: white;
            color: var(--primary-color);
        }

        .btn-white:hover {
            background-color: #f9fafb;
        }

        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 2rem;
        }

        .main-content {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .case-section {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .section-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--border-color);
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .section-subtitle {
            font-size: 0.875rem;
            color: var(--text-light);
        }

        .section-content {
            padding: 1.5rem;
        }

        .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 1.5rem;
        }

        .detail-item {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .detail-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-light);
        }

        .detail-value {
            font-size: 1rem;
            color: var(--text-color);
        }

        .timeline {
            position: relative;
            padding: 1.5rem;
        }

        .timeline::before {
            content: '';
            position: absolute;
            top: 0;
            left: 2.5rem;
            height: 100%;
            width: 2px;
            background-color: var(--border-color);
        }

        .timeline-item {
            position: relative;
            padding-left: 3.5rem;
            margin-bottom: 1.5rem;
        }

        .timeline-item:last-child {
            margin-bottom: 0;
        }

        .timeline-icon {
            position: absolute;
            left: 1.75rem;
            transform: translateX(-50%);
            width: 1.5rem;
            height: 1.5rem;
            border-radius: 50%;
            background-color: var(--primary-color);
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .timeline-content {
            background-color: #f9fafb;
            padding: 1rem;
            border-radius: 0.5rem;
        }

        .timeline-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .timeline-title {
            font-weight: 500;
            color: var(--text-color);
        }

        .timeline-date {
            font-size: 0.875rem;
            color: var(--text-light);
        }

        .timeline-body {
            color: var(--text-color);
            font-size: 0.875rem;
        }

        .action-form {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            position: sticky;
            top: 2rem;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group:last-child {
            margin-bottom: 0;
        }

        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-color);
            margin-bottom: 0.5rem;
        }

        .form-input {
            width: 100%;
            padding: 0.625rem;
            border: 1px solid var(--border-color);
            border-radius: 0.375rem;
            font-size: 0.875rem;
            color: var(--text-color);
            transition: border-color 0.2s;
        }

        .form-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 1px var(--primary-color);
        }

        textarea.form-input {
            min-height: 100px;
            resize: vertical;
        }

        .btn-submit {
            width: 100%;
            background-color: var(--primary-color);
            color: white;
            font-size: 1rem;
            padding: 0.75rem;
        }

        .btn-submit:hover {
            background-color: var(--primary-dark);
        }

        .amount {
            font-family: 'Inter', monospace;
            font-weight: 500;
            font-size: 1.5rem;
            color: var(--success-color);
        }

        .recommendation-box {
            background-color: #f0fdf4;
            border: 1px solid #6ee7b7;
            padding: 1.5rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
        }

        .recommendation-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1rem;
        }

        .recommendation-title {
            font-weight: 600;
            color: #065f46;
        }

        .recommendation-date {
            font-size: 0.875rem;
            color: #059669;
        }

        .document-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
        }

        .document-item {
            background-color: #f9fafb;
            padding: 1rem;
            border-radius: 0.5rem;
            border: 1px solid var(--border-color);
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .document-icon {
            width: 2.5rem;
            height: 2.5rem;
            background-color: var(--primary-color);
            border-radius: 0.5rem;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }

        .document-info {
            flex: 1;
        }

        .document-title {
            font-weight: 500;
            color: var(--text-color);
            margin-bottom: 0.25rem;
        }

        .document-meta {
            font-size: 0.75rem;
            color: var(--text-light);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="header-title">
                <h1>Review Case #<?php echo htmlspecialchars($case['case_id']); ?></h1>
            </div>
            <div class="header-actions">
                <a href="collector_dashboard.php" class="btn btn-white">Back to Dashboard</a>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="main-content">
            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">Case Details</h2>
                    <p class="section-subtitle">Basic information about the case</p>
                </div>
                <div class="section-content">
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Case Type</span>
                            <span class="detail-value"><?php echo htmlspecialchars($case['case_type']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Filed By</span>
                            <span class="detail-value"><?php echo htmlspecialchars($case['filed_by_name']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Filed Date</span>
                            <span class="detail-value"><?php echo date('F j, Y', strtotime($case['created_at'])); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Current Status</span>
                            <span class="detail-value"><?php echo ucfirst(str_replace('_', ' ', $case['current_status'])); ?></span>
                        </div>
                    </div>
                </div>
            </section>

            <!-- Case Documents Section -->
            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">Case Documents & Evidence</h2>
                </div>
                <div class="section-content">
                    <?php if (!empty($case_documents)): ?>
                        <ul style="list-style: none; padding: 0;">
                            <?php foreach ($case_documents as $doc): ?>
                                <li style="margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 10px;">
                                    <strong><?php echo htmlspecialchars(ucfirst($doc['document_type'])); ?>:</strong>
                                    <a href="uploads/<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" style="margin-left: 10px; color: #3498db; text-decoration: underline;">
                                        <?php echo htmlspecialchars($doc['file_path']); ?>
                                    </a>
                                    <span style="color: #888; margin-left: 10px; font-size: 0.9em;">Uploaded: <?php echo htmlspecialchars($doc['created_at']); ?></span>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p>No documents uploaded for this case.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">Victim Information</h2>
                    <p class="section-subtitle">Details about the victim</p>
                </div>
                <div class="section-content">
                    <div class="detail-grid">
                        <div class="detail-item">
                            <span class="detail-label">Name</span>
                            <span class="detail-value"><?php echo htmlspecialchars($case['victim_name']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Address</span>
                            <span class="detail-value"><?php echo htmlspecialchars($case['victim_address']); ?></span>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Incident Date</span>
                            <span class="detail-value"><?php echo date('F j, Y', strtotime($case['incident_date'])); ?></span>
                        </div>
                    </div>
                </div>
            </section>

            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">C-Section Recommendation</h2>
                    <p class="section-subtitle">Compensation recommendation from C-Section</p>
                </div>
                <div class="section-content">
                    <div class="recommendation-box">
                        <div class="recommendation-header">
                            <span class="recommendation-title">Recommended Compensation</span>
                            <span class="recommendation-date">
                                <?php echo date('M j, Y', strtotime($case['recommendation_date'])); ?>
                            </span>
                        </div>
                        <div class="amount">₹<?php echo number_format($case['recommended_amount'], 2); ?></div>
                    </div>
                </div>
            </section>

            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">Incident Description</h2>
                    <p class="section-subtitle">Detailed description of the incident</p>
                </div>
                <div class="section-content">
                    <p><?php echo nl2br(htmlspecialchars($case['incident_description'])); ?></p>
                </div>
            </section>

            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">Case History</h2>
                    <p class="section-subtitle">Timeline of case updates and actions</p>
                </div>
                <div class="timeline">
                    <?php foreach ($history as $entry): ?>
                        <div class="timeline-item">
                            <div class="timeline-icon"></div>
                            <div class="timeline-content">
                                <div class="timeline-header">
                                    <span class="timeline-title">
                                        <?php echo ucfirst(str_replace('_', ' ', $entry['status'])); ?>
                                    </span>
                                    <span class="timeline-date">
                                        <?php echo date('M j, Y g:i A', strtotime($entry['date'])); ?>
                                    </span>
                                </div>
                                <?php if ($entry['comments']): ?>
                                    <div class="timeline-body">
                                        <?php echo htmlspecialchars($entry['comments']); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </section>

            <section class="case-section">
                <div class="section-header">
                    <h2 class="section-title">Documents</h2>
                    <p class="section-subtitle">Case related documents and evidence</p>
                </div>
                <div class="section-content">
                    <div class="document-grid">
                        <div class="document-item">
                            <div class="document-icon">📄</div>
                            <div class="document-info">
                                <div class="document-title">FIR Copy</div>
                                <div class="document-meta">PDF • 2.3 MB</div>
                            </div>
                        </div>
                        <div class="document-item">
                            <div class="document-icon">📷</div>
                            <div class="document-info">
                                <div class="document-title">Evidence Photos</div>
                                <div class="document-meta">ZIP • 15.7 MB</div>
                            </div>
                        </div>
                        <div class="document-item">
                            <div class="document-icon">📋</div>
                            <div class="document-info">
                                <div class="document-title">Medical Report</div>
                                <div class="document-meta">PDF • 1.8 MB</div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <div class="action-form">
            <div class="section-header">
                <h2 class="section-title">Review Action</h2>
                <p class="section-subtitle">Approve compensation and forward to Social Welfare</p>
            </div>
            <form id="forward-form" action="handlers/process_case.php" method="POST" class="section-content">
                <input type="hidden" name="case_id" value="<?php echo htmlspecialchars($case['case_id']); ?>">
                <input type="hidden" name="action" value="forward_to_social_welfare">
                <div class="form-group">
                    <label class="form-label" for="approved_amount">Approved Compensation Amount (₹)</label>
                    <input type="number" id="approved_amount" name="approved_amount" class="form-input" required min="0" step="1000" value="<?php echo $case['recommended_amount']; ?>">
                </div>
                <div class="form-group">
                    <label class="form-label" for="comments">Review Comments</label>
                    <textarea id="comments" name="comments" class="form-input" required placeholder="Enter your review comments and approval notes..."></textarea>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-submit">Forward to Social Welfare</button>
                </div>
            </form>
            <!-- Modal for Success -->
            <div id="success-modal" style="display:none;position:fixed;z-index:9999;left:0;top:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);align-items:center;justify-content:center;">
                <div style="background:white;padding:2rem 2.5rem;border-radius:10px;box-shadow:0 4px 24px rgba(0,0,0,0.2);text-align:center;max-width:90vw;">
                    <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/376px-Emblem_of_India.svg.png' alt='Emblem' style='height:60px;margin-bottom:1rem;'>
                    <h2 style="color:#059669;margin-bottom:1rem;">Case Forwarded Successfully!</h2>
                    <p style="font-size:1.1rem;">The case has been forwarded to the Social Welfare Department.<br>All documents and information are now available for further investigation.</p>
                    <button id="close-modal-btn" class="btn btn-submit" style="margin-top:1.5rem;">Go to Dashboard</button>
                </div>
            </div>
            <script>
            document.getElementById('forward-form').addEventListener('submit', function(e) {
                e.preventDefault();
                var form = this;
                var formData = new FormData(form);
                fetch(form.action, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('success-modal').style.display = 'flex';
                        document.getElementById('close-modal-btn').onclick = function() {
                            window.location.href = 'collector_dashboard.php';
                        };
                        // Optionally update dashboard stats via AJAX here
                    } else {
                        alert(data.message || 'An error occurred.');
                    }
                })
                .catch(() => alert('An error occurred while forwarding the case.'));
            });
            </script>
        </div>
    </div>
</body>
</html> 