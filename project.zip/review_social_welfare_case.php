<?php
require_once 'includes/auth.php';
requireRole('social_welfare');

if (!isset($_GET['case_id'])) {
    header('Location: social_welfare_dashboard.php?error=No case ID provided');
    exit();
}

$case_id = $_GET['case_id'];

try {
    // Get case details with latest status
    $stmt = $pdo->prepare("
        WITH LatestStatus AS (
            SELECT 
                case_id,
                status,
                comments,
                created_at,
                ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY created_at DESC) as rn
            FROM case_status
            WHERE case_id = ?
        )
        SELECT 
            c.*,
            ls.status as current_status,
            ls.comments as status_comments,
            u.username as filed_by_name,
            ca.approved_amount as collector_approved_amount,
            ca.created_at as collector_approval_date,
            cr.recommended_amount,
            cr.created_at as recommendation_date
        FROM cases c
        JOIN LatestStatus ls ON c.case_id = ls.case_id AND ls.rn = 1
        JOIN users u ON c.filed_by = u.id
        LEFT JOIN compensation_approvals ca ON c.case_id = ca.case_id
        LEFT JOIN compensation_recommendations cr ON c.case_id = cr.case_id
        WHERE c.case_id = ?
    ");
    
    $stmt->execute([$case_id, $case_id]);
    $case = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$case) {
        throw new Exception('Case not found');
    }

    // Get case documents
    $stmt = $pdo->prepare("SELECT * FROM case_documents WHERE case_id = ? ORDER BY created_at DESC");
    $stmt->execute([$case_id]);
    $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Get status history
    $stmt = $pdo->prepare("
        SELECT 
            cs.*,
            u.username as updated_by_name
        FROM case_status cs
        JOIN users u ON cs.created_by = u.id
        WHERE cs.case_id = ?
        ORDER BY cs.created_at DESC
    ");
    $stmt->execute([$case_id]);
    $status_history = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(Exception $e) {
    error_log("Error in review_social_welfare_case.php: " . $e->getMessage());
    header('Location: social_welfare_dashboard.php?error=' . urlencode($e->getMessage()));
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Review Case - Social Welfare Department</title>
    <link rel="stylesheet" href="css/styles.css">
    <style>
        .case-details {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .section {
            margin-bottom: 30px;
        }
        .section h2 {
            color: #1a73e8;
            margin-bottom: 15px;
        }
        .detail-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        .detail-item {
            margin-bottom: 15px;
        }
        .detail-label {
            font-weight: bold;
            color: #666;
        }
        .detail-value {
            margin-top: 5px;
        }
        .documents-list {
            list-style: none;
            padding: 0;
        }
        .document-item {
            padding: 10px;
            border: 1px solid #ddd;
            margin-bottom: 10px;
            border-radius: 4px;
        }
        .status-history {
            list-style: none;
            padding: 0;
        }
        .status-item {
            padding: 15px;
            border-left: 3px solid #1a73e8;
            margin-bottom: 15px;
            background: #f8f9fa;
        }
        .status-date {
            color: #666;
            font-size: 0.9em;
        }
        .action-buttons {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 500;
        }
        .btn-approve {
            background-color: #28a745;
            color: white;
        }
        .btn-reject {
            background-color: #dc3545;
            color: white;
        }
        .amount {
            font-family: monospace;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <main class="container">
        <h1>Review Case #<?php echo htmlspecialchars($case['case_id']); ?></h1>
        
        <div class="case-details">
            <div class="section">
                <h2>Case Information</h2>
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">Victim Name</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['victim_name']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Case Type</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['case_type']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Incident Date</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['incident_date']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Filed By</div>
                        <div class="detail-value"><?php echo htmlspecialchars($case['filed_by_name']); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Recommended Amount</div>
                        <div class="detail-value amount">₹<?php echo number_format($case['recommended_amount'], 2); ?></div>
                    </div>
                    <div class="detail-item">
                        <div class="detail-label">Collector Approved Amount</div>
                        <div class="detail-value amount">₹<?php echo number_format($case['collector_approved_amount'], 2); ?></div>
                    </div>
                </div>
            </div>

            <div class="section">
                <h2>Case Documents</h2>
                <ul class="documents-list">
                    <?php foreach ($documents as $doc): ?>
                        <li class="document-item">
                            <div><strong><?php echo htmlspecialchars($doc['document_type']); ?></strong></div>
                            <a href="uploads/<?php echo htmlspecialchars($doc['file_path']); ?>" target="_blank" class="btn btn-primary">
                                Download Document
                            </a>
                            <div>Uploaded: <?php echo htmlspecialchars($doc['created_at']); ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="section">
                <h2>Status History</h2>
                <ul class="status-history">
                    <?php foreach ($status_history as $status): ?>
                        <li class="status-item">
                            <div class="status-date">
                                <?php echo htmlspecialchars($status['created_at']); ?> by 
                                <?php echo htmlspecialchars($status['updated_by_name']); ?>
                            </div>
                            <div><strong><?php echo ucwords(str_replace('_', ' ', $status['status'])); ?></strong></div>
                            <?php if (!empty($status['comments'])): ?>
                                <div><?php echo htmlspecialchars($status['comments']); ?></div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>

            <div class="section">
                <h2>Process Case</h2>
                <form id="process-form" action="handlers/process_social_welfare_case.php" method="POST">
                    <input type="hidden" name="case_id" value="<?php echo htmlspecialchars($case['case_id']); ?>">
                    <div class="form-group">
                        <label for="comments">Comments/Remarks</label>
                        <textarea name="comments" id="comments" rows="4" class="form-control" required></textarea>
                    </div>
                    <div class="action-buttons">
                        <button type="submit" name="action" value="approve" class="btn btn-approve">Approve Compensation</button>
                        <button type="submit" name="action" value="reject" class="btn btn-reject">Reject Case</button>
                        <a href="social_welfare_dashboard.php" class="btn btn-secondary">Back to Dashboard</a>
                    </div>
                </form>
                <!-- Modal for Success -->
                <div id="success-modal" style="display:none;position:fixed;z-index:9999;left:0;top:0;width:100vw;height:100vh;background:rgba(0,0,0,0.3);align-items:center;justify-content:center;">
                    <div style="background:white;padding:2rem 2.5rem;border-radius:10px;box-shadow:0 4px 24px rgba(0,0,0,0.2);text-align:center;max-width:90vw;">
                        <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/Emblem_of_India.svg/376px-Emblem_of_India.svg.png' alt='Emblem' style='height:60px;margin-bottom:1rem;'>
                        <h2 style="color:#059669;margin-bottom:1rem;">Case Processed Successfully!</h2>
                        <p style="font-size:1.1rem;">The case has been processed.<br>All documents and information are now available for further action.</p>
                        <button id="close-modal-btn" class="btn btn-approve" style="margin-top:1.5rem;">Go to Dashboard</button>
                    </div>
                </div>
                <script>
                document.getElementById('process-form').addEventListener('submit', function(e) {
                    e.preventDefault();
                    var form = this;
                    var formData = new FormData(form);
                    fetch(form.action, {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            document.getElementById('success-modal').style.display = 'flex';
                            document.getElementById('close-modal-btn').onclick = function() {
                                window.location.href = 'social_welfare_dashboard.php';
                            };
                            // Optionally update dashboard stats via AJAX here
                        } else {
                            alert(data.message || 'An error occurred.');
                        }
                    })
                    .catch(() => alert('An error occurred while processing the case.'));
                });
                </script>
            </div>
        </div>
    </main>
</body>
</html> 