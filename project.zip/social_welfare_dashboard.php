<?php
require_once 'includes/auth.php';
requireRole('social_welfare');

// Get statistics
try {
    $stmt = $pdo->prepare("
        WITH LatestStatus AS (
            SELECT 
                case_id,
                status,
                created_at,
                ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY created_at DESC) as rn
            FROM case_status
        )
        SELECT 
            (SELECT COUNT(*) FROM cases) as total_cases,
            (
                SELECT COUNT(*) 
                FROM LatestStatus
                WHERE status = 'social_welfare_review'
                AND rn = 1
            ) as pending_verification,
            (
                SELECT COUNT(*) 
                FROM LatestStatus
                WHERE status = 'compensation_approved'
                AND rn = 1
            ) as verified_cases,
            (
                SELECT COUNT(*) 
                FROM LatestStatus
                WHERE status = 'compensation_paid'
                AND rn = 1
            ) as compensated_cases
    ");
    
    $stmt->execute();
    $stats = $stmt->fetch(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error fetching statistics: " . $e->getMessage());
    $stats = [
        'total_cases' => 0,
        'pending_verification' => 0,
        'verified_cases' => 0,
        'compensated_cases' => 0
    ];
}

// Get cases pending social welfare review
try {
    $stmt = $pdo->prepare("
        WITH LatestStatus AS (
            SELECT 
                case_id,
                status,
                created_at,
                ROW_NUMBER() OVER (PARTITION BY case_id ORDER BY created_at DESC) as rn
            FROM case_status
        )
        SELECT 
            c.*,
            ls.status as current_status,
            u.username as filed_by_name,
            ca.approved_amount,
            ca.created_at as approval_date,
            cr.recommended_amount
        FROM cases c
        JOIN LatestStatus ls ON c.case_id = ls.case_id AND ls.rn = 1
        JOIN users u ON c.filed_by = u.id
        LEFT JOIN compensation_approvals ca ON c.case_id = ca.case_id
        LEFT JOIN compensation_recommendations cr ON c.case_id = cr.case_id
        WHERE ls.status = 'social_welfare_review'
        ORDER BY c.created_at DESC
    ");
    $stmt->execute();
    $pending_cases = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Error fetching pending cases: " . $e->getMessage());
    $pending_cases = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Social Welfare Dashboard - SC/ST Case Management</title>
    <link rel="stylesheet" href="css/styles.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --success-color: #2ecc71;
            --warning-color: #f1c40f;
            --danger-color: #e74c3c;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f5f6fa;
        }
        
        .nav-bar {
            background-color: var(--primary-color);
            padding: 15px;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .nav-bar h2 {
            margin: 0;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .nav-bar a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 4px;
            background-color: var(--secondary-color);
        }
        
        .dashboard-container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 0 20px;
        }
        
        .stats-container {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            text-align: center;
            transition: all 0.3s ease;
        }
        
        .stat-card.updated {
            background-color: #e8f5e9;
        }
        
        .stat-number {
            font-size: 2em;
            color: var(--primary-color);
            font-weight: bold;
        }
        
        .stat-label {
            color: #7f8c8d;
            margin-top: 5px;
        }
        
        .cases-table {
            width: 100%;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-top: 20px;
            overflow: hidden;
        }
        
        .cases-table table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .cases-table th, .cases-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .cases-table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        
        .cases-table tr:hover {
            background-color: #f5f6fa;
        }
        
        .status-badge {
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.85em;
            font-weight: 500;
        }
        
        .status-social_welfare {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .status-completed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .status-approved {
            background-color: #cce5ff;
            color: #004085;
        }
        
        .status-disbursed {
            background-color: #d4edda;
            color: #155724;
        }
        
        .btn {
            padding: 8px 15px;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            text-decoration: none;
            display: inline-block;
            font-size: 0.9em;
        }
        
        .btn-primary {
            background-color: var(--secondary-color);
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #2980b9;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .amount {
            font-family: monospace;
        }
    </style>
    <script>
        function refreshStats() {
            $.ajax({
                url: 'handlers/get_social_welfare_stats.php',
                method: 'GET',
                success: function(response) {
                    try {
                        const stats = JSON.parse(response);
                        updateStatWithAnimation('#total-cases', stats.total_cases);
                        updateStatWithAnimation('#pending-verification', stats.pending_verification);
                        updateStatWithAnimation('#verified-cases', stats.verified_cases);
                        updateStatWithAnimation('#compensated-cases', stats.compensated_cases);
                    } catch(e) {
                        console.error('Error parsing statistics:', e);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching statistics:', error);
                }
            });
        }

        function updateStatWithAnimation(selector, newValue) {
            const element = $(selector);
            const oldValue = parseInt(element.text());
            if (oldValue !== newValue) {
                element.closest('.stat-card').addClass('updated');
                element.text(newValue);
                setTimeout(() => {
                    element.closest('.stat-card').removeClass('updated');
                }, 1000);
            }
        }

        $(document).ready(function() {
            setInterval(refreshStats, 5000);
            
            $('#refresh-btn').click(function(e) {
                e.preventDefault();
                refreshStats();
            });

            if (window.location.search.includes('success=1')) {
                refreshStats();
            }
        });
    </script>
</head>
<body>
    <div class="nav-bar">
        <h2>Social Welfare Dashboard</h2>
        <div class="user-info">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="dashboard-container">
        <?php if (isset($_GET['success']) && $_GET['success'] == 1): ?>
            <div class="alert alert-success">
                Case has been successfully processed and compensation has been approved.
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <button id="refresh-btn" class="refresh-button">
            <i class="fas fa-sync"></i> Refresh Dashboard
        </button>

        <div class="stats-container">
            <div class="stat-card">
                <h3>Total Cases</h3>
                <p id="total-cases"><?php echo $stats['total_cases']; ?></p>
            </div>
            <div class="stat-card">
                <h3>Pending Verification</h3>
                <p id="pending-verification"><?php echo $stats['pending_verification']; ?></p>
            </div>
            <div class="stat-card">
                <h3>Verified Cases</h3>
                <p id="verified-cases"><?php echo $stats['verified_cases']; ?></p>
            </div>
            <div class="stat-card">
                <h3>Compensated Cases</h3>
                <p id="compensated-cases"><?php echo $stats['compensated_cases']; ?></p>
            </div>
        </div>

        <div class="cases-section">
            <h2>Cases Pending Verification</h2>
            <?php if (count($pending_cases) > 0): ?>
                <table class="cases-table">
                    <thead>
                        <tr>
                            <th>Case ID</th>
                            <th>Filed By</th>
                            <th>Victim Name</th>
                            <th>Incident Date</th>
                            <th>Collector Approved Amount</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending_cases as $case): ?>
                            <tr>
                                <td>#<?php echo htmlspecialchars($case['case_id']); ?></td>
                                <td><?php echo htmlspecialchars($case['filed_by_name']); ?></td>
                                <td><?php echo htmlspecialchars($case['victim_name']); ?></td>
                                <td><?php echo htmlspecialchars($case['incident_date']); ?></td>
                                <td class="amount">₹<?php echo number_format($case['approved_amount'], 2); ?></td>
                                <td>
                                    <a href="review_social_welfare_case.php?case_id=<?php echo $case['case_id']; ?>" 
                                       class="btn btn-primary">Review Case</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <p>No cases pending verification at this time.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-hide alerts after 5 seconds
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s';
                setTimeout(() => alert.remove(), 500);
            }, 5000);
        });
    });
    </script>
</body>
</html> 