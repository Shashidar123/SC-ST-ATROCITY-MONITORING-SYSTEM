<?php
require_once 'includes/auth.php';
requireRole('rdo');

// Get statistics
try {
    $stmt = $pdo->prepare("
        SELECT 
            COUNT(*) as total_cases,
            SUM(CASE WHEN status = 'sp_review' THEN 1 ELSE 0 END) as pending_review,
            SUM(CASE WHEN status = 'c_section_review' THEN 1 ELSE 0 END) as forwarded_cases
        FROM cases c
        JOIN case_status cs ON c.case_id = cs.case_id
        WHERE cs.created_at = (
            SELECT MAX(created_at)
            FROM case_status
            WHERE case_id = c.case_id
        )
    ");
    $stmt->execute();
    $stats = $stmt->fetch();
} catch(PDOException $e) {
    $stats = ['total_cases' => 0, 'pending_review' => 0, 'forwarded_cases' => 0];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SP Dashboard - SC/ST Case Management</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #1a56db;
            --primary-dark: #1e429f;
            --secondary-color: #e2e8f0;
            --success-color: #059669;
            --warning-color: #d97706;
            --danger-color: #dc2626;
            --background-color: #f3f4f6;
            --text-color: #1f2937;
            --text-light: #6b7280;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', sans-serif;
        }

        body {
            background-color: var(--background-color);
            color: var(--text-color);
            line-height: 1.5;
        }

        .header {
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
            color: white;
            padding: 1.5rem 2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .header-title h1 {
            font-size: 1.5rem;
            font-weight: 600;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 1.5rem;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .user-name {
            font-weight: 500;
        }

        .btn {
            padding: 0.625rem 1.25rem;
            border-radius: 0.5rem;
            font-weight: 500;
            text-decoration: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            cursor: pointer;
            border: none;
        }

        .btn-logout {
            background-color: rgba(255,255,255,0.1);
            color: white;
        }

        .btn-logout:hover {
            background-color: rgba(255,255,255,0.2);
        }

        .container {
            max-width: 1400px;
            margin: 2rem auto;
            padding: 0 2rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: white;
            padding: 1.5rem;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-number {
            font-size: 2rem;
            font-weight: 600;
            color: var(--primary-color);
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--text-light);
            font-size: 0.875rem;
            font-weight: 500;
        }

        .cases-section {
            background: white;
            border-radius: 0.75rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .section-header {
            padding: 1.5rem;
            border-bottom: 1px solid var(--secondary-color);
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-color);
        }

        .cases-table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
        }

        .cases-table th {
            background-color: #f8fafc;
            padding: 1rem 1.5rem;
            text-align: left;
            font-weight: 600;
            color: var(--text-light);
            border-bottom: 1px solid var(--secondary-color);
        }

        .cases-table td {
            padding: 1rem 1.5rem;
            border-bottom: 1px solid var(--secondary-color);
        }

        .cases-table tr:last-child td {
            border-bottom: none;
        }

        .cases-table tr:hover {
            background-color: #f8fafc;
        }

        .status-badge {
            display: inline-flex;
            align-items: center;
            padding: 0.375rem 0.75rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 500;
        }

        .status-sp_review {
            background-color: #fef3c7;
            color: #92400e;
        }

        .status-c_section_review {
            background-color: #d1fae5;
            color: #065f46;
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .btn-primary:hover {
            background-color: var(--primary-dark);
        }

        .alert {
            padding: 1rem 1.5rem;
            border-radius: 0.5rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .alert-success {
            background-color: #ecfdf5;
            color: #065f46;
            border: 1px solid #6ee7b7;
        }

        .alert-error {
            background-color: #fef2f2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }

        .empty-state {
            padding: 3rem 1.5rem;
            text-align: center;
            color: var(--text-light);
        }
    </style>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="header-title">
                <h1>SP Dashboard</h1>
            </div>
            <div class="header-actions">
                <div class="user-info">
                    <span class="user-name">Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
                </div>
                <a href="logout.php" class="btn btn-logout">Logout</a>
            </div>
        </div>
    </header>

    <main class="container">
        <?php if (isset($_GET['success'])): ?>
            <div class="alert alert-success">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" style="width: 20px; height: 20px;">
                    <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" />
                </svg>
                Case has been successfully forwarded to C-Section.
            </div>
        <?php endif; ?>

        <?php if (isset($_GET['error'])): ?>
            <div class="alert alert-error">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" style="width: 20px; height: 20px;">
                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd" />
                </svg>
                <?php echo htmlspecialchars($_GET['error']); ?>
            </div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['total_cases'] ?? 0; ?></div>
                <div class="stat-label">Total Cases</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['pending_review'] ?? 0; ?></div>
                <div class="stat-label">Pending Review</div>
            </div>
            <div class="stat-card">
                <div class="stat-number"><?php echo $stats['forwarded_cases'] ?? 0; ?></div>
                <div class="stat-label">Forwarded to C-Section</div>
            </div>
        </div>

        <div class="cases-section">
            <div class="section-header">
                <h2 class="section-title">Cases Pending Review</h2>
            </div>
            <?php
            try {
                $stmt = $pdo->prepare("
                    SELECT 
                        c.*,
                        cs.status as current_status,
                        cs.created_at as status_date,
                        u.username as filed_by_name
                    FROM cases c
                    JOIN case_status cs ON c.case_id = cs.case_id
                    JOIN users u ON c.filed_by = u.id
                    WHERE cs.created_at = (
                        SELECT MAX(created_at)
                        FROM case_status
                        WHERE case_id = c.case_id
                    )
                    ORDER BY cs.created_at DESC
                ");
                $stmt->execute();
                $cases = $stmt->fetchAll();

                if (count($cases) > 0):
            ?>
                <table class="cases-table">
                    <thead>
                        <tr>
                            <th>Case ID</th>
                            <th>Victim Name</th>
                            <th>Case Type</th>
                            <th>Filed By</th>
                            <th>Filed Date</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($cases as $case): ?>
                            <tr>
                                <td>#<?php echo htmlspecialchars($case['case_id']); ?></td>
                                <td><?php echo htmlspecialchars($case['victim_name']); ?></td>
                                <td><?php echo htmlspecialchars($case['case_type']); ?></td>
                                <td><?php echo htmlspecialchars($case['filed_by_name']); ?></td>
                                <td><?php echo date('M j, Y', strtotime($case['created_at'])); ?></td>
                                <td>
                                    <span class="status-badge status-<?php echo htmlspecialchars($case['current_status']); ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $case['current_status'])); ?>
                                    </span>
                                </td>
                                <td>
                                    <a href="review_case.php?case_id=<?php echo $case['case_id']; ?>" class="btn btn-primary">Review Case</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="empty-state">
                    <p>No cases pending review at this time.</p>
                </div>
            <?php 
                endif;
            } catch(PDOException $e) {
                echo "<div class='empty-state'><p>Error loading cases: " . htmlspecialchars($e->getMessage()) . "</p></div>";
            }
            ?>
        </div>
    </main>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Auto-hide alerts after 5 seconds
        const alerts = document.querySelectorAll('.alert');
        alerts.forEach(alert => {
            setTimeout(() => {
                alert.style.opacity = '0';
                alert.style.transition = 'opacity 0.5s';
                setTimeout(() => alert.remove(), 500);
            }, 5000);
        });
    });

    function refreshStats() {
        fetch('handlers/get_stats.php')
            .then(response => response.json())
            .then(stats => {
                document.querySelector('.stat-card:nth-child(1) .stat-number').textContent = stats.total_cases;
                document.querySelector('.stat-card:nth-child(2) .stat-number').textContent = stats.pending_review;
                document.querySelector('.stat-card:nth-child(3) .stat-number').textContent = stats.forwarded_cases;
            });
    }
    // Optionally, call refreshStats after a successful forward (see modal logic in review_case.php)
    </script>
</body>
</html> 